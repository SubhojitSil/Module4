package com.sg.product.dao;

public interface IProductDAO {
	public int getPrice(String name);

}
