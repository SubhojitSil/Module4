package com.bookAuthor.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



@Entity
@Table(name = "author_tbl")
public class Author {
	@Id
	@GeneratedValue
	private int id;
	@Column(name = "author_name", length = 15)
	private String name;
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="author")
	private Set<Books> books = new HashSet<>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Books> getBooks() {
		return books;
	}
	public void setBooks(Set<Books> books) {
		this.books = books;
	}
	@Override
	public String toString() {
		return " name= " + name  ;
	}

	
}
