package com.bookAuthor.entities;

import java.awt.print.Book;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;



public class QuerryClass {
public static void main(String[] args) {
	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	/*String qryStr= "from Books";
	TypedQuery<Books> query= em.createQuery(qryStr,Books.class);
	List<Books> list = query.getResultList();
	for(Books b:list)
	{
		System.out.println(b.getIsbn());
		System.out.println(b.getTitle());
		System.out.println(b.getPrice());
		
		//System.out.println(b.getAuthor());
		Set<Author> set = new HashSet<Author>();
		set=b.getAuthor();
		for(Author a:set){
			System.out.println(a.getName());
		}
		
	}*/
	//String qryStr="from Books where name=:name";
	/*TypedQuery<Author> qry= em.createQuery("from Author where author_name=:name1", Author.class);
	qry.setParameter("name1", "AUTHOR 2");
	List<Author> list = qry.getResultList();
	for(Author b:list)
	{
		Set<Books> books=b.getBooks();
		for(Books b1:books)
		{
			System.out.println(b1.getTitle());
		}
	}*/
	
	/*TypedQuery<Books> qry= em.createQuery("from Books where price between 500 and 1000", Books.class);
	List<Books> list= qry.getResultList();
	for(Books b:list)
	{
		System.out.println(b.getTitle());
	}*/
	
	TypedQuery<Books> qry= em.createQuery("from Books where isbn=:id", Books.class);
	qry.setParameter("id", 4);
	Books searchedBook=qry.getSingleResult();
	Set<Author> authors= searchedBook.getAuthor();
	for(Author author:authors){
		System.out.println(author.getName());
	}
	
}
}
