package com.bookAuthor.entities;

import java.awt.print.Book;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Author author1= new Author();
		author1.setName("AUTHOR 1");
		
		Author author2= new Author();
		author2.setName("AUTHOR 2");
		
		Author author3= new Author();
		author3.setName("AUTHOR 3");
		
		Books book1= new Books();
		book1.setAuthor(author1);
		book1.setAuthor(author2);
		book1.setTitle("Book 1");
		book1.setPrice(450);
		
		Books book2= new Books();
		book2.setAuthor(author2);
		book2.setAuthor(author3);
		 book2.setTitle("Book 2");
		 book2.setPrice(900);
		 
		 em.persist(book1);
		 em.persist(book2);
		
		
		
		
		
		
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

}
