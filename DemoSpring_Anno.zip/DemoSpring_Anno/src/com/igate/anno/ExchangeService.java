package com.igate.anno;

public interface ExchangeService {
	public double getExchangeRate();
}
