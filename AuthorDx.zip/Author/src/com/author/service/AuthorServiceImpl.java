package com.author.service;

import java.util.List;

import com.author.bean.Author;
import com.author.dao.AuthorDaoImpl;
import com.author.dao.IAuthorDao;
import com.author.exception.AuthorException;

public class AuthorServiceImpl implements IAuthorService {
private  IAuthorDao authorDao;
public AuthorServiceImpl() {
	 authorDao = new AuthorDaoImpl();
}
	@Override
	public int addAuthor(Author author) throws AuthorException {
		int id=authorDao.addAuthor(author);
		return id;
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		Author deletedAuthor= authorDao.deleteAuthor(id);
		return deletedAuthor;
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {
		Author searchedAuthor= authorDao.findAuthor(id);
		return searchedAuthor;
	}

	@Override
	public List<Author> viewAllAuthor() throws AuthorException {
		List<Author> list= authorDao.viewAllAuthor();
		return list;
	}
	@Override
	public Author updateAuthor(int id, String phoneNumber)
			throws AuthorException {
		Author updatedAuthor=authorDao.updateAuthor(id, phoneNumber);
		return updatedAuthor;
	}

}
