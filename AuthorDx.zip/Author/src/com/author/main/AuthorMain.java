package com.author.main;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.author.bean.Author;
import com.author.exception.AuthorException;
import com.author.service.AuthorServiceImpl;
import com.author.service.IAuthorService;


public class AuthorMain {

	public static void main(String[] args) throws IOException, AuthorException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
int choice=0;

IAuthorService authorobj;
authorobj=new AuthorServiceImpl();
Author author= new Author();
char c='y';
do{
System.out.println("1 for Insert");
System.out.println("2 for Delete");
System.out.println("3 for search");
System.out.println("4 for display all");
System.out.println("5 for update phone number ");
System.out.println("6 to close");
choice=Integer.parseInt(br.readLine());
switch (choice){
case 1:
	
	System.out.println("enter first name");
	
	author.setFirstName(br.readLine());
	System.out.println("enter middle name");
	author.setMiddleName(br.readLine());
	System.out.println("enter last name");
	author.setLastName(br.readLine());
	System.out.println("enter phone number");
	author.setPhoneNumber(br.readLine());
	int id=authorobj.addAuthor(author);
	System.out.println("ID is "+id);
	break;
case 2:
	System.out.println("Enter the id");
	author=authorobj.deleteAuthor(Integer.parseInt(br.readLine()));
	System.out.println(author);
	break;
case 3:
	System.out.println("Enter the id");
	author=authorobj.findAuthor(Integer.parseInt(br.readLine()));
	System.out.println(author);
	break;
case 4:
	List<Author> list= authorobj.viewAllAuthor();
	for(Author auth:list){
		System.out.println(auth);
	}
	break;
case 5:
	System.out.println("enter id");
	int idup=Integer.parseInt(br.readLine());
	
	System.out.println("enter the new phone number");
	String contactInfo=br.readLine();
	author=authorobj.updateAuthor(idup,contactInfo );
	
	break;
case 6:
	System.exit(0);
	break;
	default:
		System.out.println("invalid choice");
		break;
}

}while(c=='y');
	}

}
