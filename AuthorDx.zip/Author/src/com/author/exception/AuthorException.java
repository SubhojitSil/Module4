package com.author.exception;

public class AuthorException extends Exception{
public AuthorException(String message){
	super (message);
}
}
