package com.author.dao;

import java.util.List;

import com.author.bean.Author;
import com.author.exception.AuthorException;

public interface IAuthorDao {
public int addAuthor(Author author)throws AuthorException;
public Author deleteAuthor(int id) throws AuthorException;
public Author findAuthor(int id) throws AuthorException;
public List<Author> viewAllAuthor() throws AuthorException;
public Author updateAuthor(int id, String phoneNumber) throws AuthorException;


}
