package com.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.author.bean.Author;
import com.author.exception.AuthorException;



public class AuthorDaoImpl implements IAuthorDao {
	

	private EntityManager entityManager;
	
	
	public AuthorDaoImpl() {
		entityManager = com.author.util.JPAUtil.getEntityManager();
			
	}

	@Override
	public int addAuthor(Author author) throws AuthorException {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(author);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			
			throw new AuthorException(e.getMessage());
		}
		return author.getAuthorId();
	}

	@Override
	public Author deleteAuthor(int id) throws AuthorException {
		Author author;
		try {
			author = entityManager.find(Author.class, id);
			if(author==null){
				System.out.println("Author doesnot exist with id: " + id);
			}else{
				System.out.println("AUTHOR DELETED");
				entityManager.remove(author);
			}
		} catch (Exception e) {
			
			throw new AuthorException(e.getMessage());
		}
		
		return author;
	}

	@Override
	public Author findAuthor(int id) throws AuthorException {
	Author author;
		try {
			author= entityManager.find(Author.class, id);
			if(author==null){
				System.out.println("Author doesnot exist with id: " + id);
			}else{
				System.out.println("AUTHOR FOUND");
			}
		} catch (Exception e) {
			throw new AuthorException(e.getMessage());
		}
		return author;
		
	}

	@Override
	public List<Author> viewAllAuthor() throws AuthorException {
		TypedQuery<Author> query= entityManager.createNamedQuery("viewAllAuthor", Author.class);
		List<Author> list = query.getResultList();
		return list;
	}

	@Override
	public Author updateAuthor(int id, String phoneNumber)
			throws AuthorException {
		Author author;
		try {
			author= entityManager.find(Author.class, id);
			if(author==null){
				System.out.println("Author doesnot exist with id: " + id);
			}else{
				author.setPhoneNumber(phoneNumber);
				System.out.println("updated");
			}
		} catch (Exception e) {
			throw new AuthorException(e.getMessage());
		}
		return author;
	}
	

}
