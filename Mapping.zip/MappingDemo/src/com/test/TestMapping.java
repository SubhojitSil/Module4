package com.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestMapping {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		em.getTransaction().begin();

		Employee emp = new Employee();
		emp.setEmployeeName("BROCK");
		Department dept = new Department();

		dept.setDepartmentName("FS");

		emp.setDepartment(dept);

		em.persist(emp); // CASCADING done in Parent Class
		//em.persist(dept); WITHOUT CASCADING

		em.getTransaction().commit();
		
		System.out.println("Employee Added");
		em.close();
		factory.close();
	}

}
